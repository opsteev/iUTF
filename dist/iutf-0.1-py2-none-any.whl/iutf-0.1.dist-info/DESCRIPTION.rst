iUTF is a Unit Test framework for networking devices like switch, router, controller, ap.
And also it can remote control linux and mac via telnet or ssh.

It converts the prompt of devices to nodes and combines the nodes to a graph, then use the 
shortest path algorithm to find the path switching between nodes.

iUTF requires pexpect, nose, logging.


